# Technical Audit Notes (2026-03-06)

This repository was reviewed for architecture, database portability, security controls, and upgrade risks.

Key observations:
- Persistence is JSON-file based (`core/data/store.json`, `core/data/accounts.json`) via `core/src/models/store.js` and `core/src/services/json-db.js`.
- No SQL/ORM layer exists in current codebase.
- Admin API uses token auth in-memory and broad CORS (`*`), requiring hardening for internet-facing deployments.
- Default admin password is `admin` unless overridden.

See assistant response for detailed, evidence-based report.
